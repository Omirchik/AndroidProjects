package com.example.calculator;

import java.util.List;

class ParsePost
{
    private Stack theStack;
    private List<String> input;
    //--------------------------------------------------------------
    public ParsePost(List<String> s) {
        input = s;
    }

    public float doParse()
    {
        theStack = new Stack(20);
        char ch;
        int j;
        float num1, num2, interAns;
        for(j=0; j<input.size(); j++)
        {
            String s=input.get(j);
            ch = s.charAt(0);
            if(Character.isDigit(ch) || (j==0 && input.get(0).charAt(0)=='-'))
                theStack.push(Float.parseFloat(s));
            else
            {
                num2 = theStack.pop();
                num1 = theStack.pop();
                switch(ch)
                {
                    case '+':
                        interAns = num1 + num2;
                        break;
                    case '-':
                        interAns = num1 - num2;
                        break;
                    case '*':
                        interAns = num1 * num2;
                        break;
                    case '/':
                        interAns = num1 / num2;
                        break;
                    default:
                        interAns = 0;
                }
                theStack.push(interAns);
            }
        }
        interAns = theStack.pop();
        return interAns;
    }
}