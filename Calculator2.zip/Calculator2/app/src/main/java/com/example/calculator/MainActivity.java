package com.example.calculator;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    private TextView display;
    private String currentText="0";
    private final static String EXXPRESSTION="EXPRESS";
    private final static String ANSWER="ANSWER";
    private TextView displayResult;
    private String answerText="";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        if (savedInstanceState!=null){
            currentText=savedInstanceState.getString(EXXPRESSTION,"0");
            answerText=savedInstanceState.getString(ANSWER,"");
        }
        display=findViewById(R.id.text_view);
        displayResult=findViewById(R.id.text_view_result);
        display.setText(currentText);
        displayResult.setText(answerText);
    }
    public void ButtonPressed(View v){

        Button buttonPress=(Button) v;
        currentText=display.getText().toString();

        if (currentText.equals("0") && buttonPress.getText().toString().charAt(0)!='.'){
            currentText="";
        }

        currentText+=buttonPress.getText().toString();
        display.setText(currentText);
    }
    public void equalPressed(View v){

        String s = display.getText().toString();

        InToPost post=new InToPost(s);

        List<String> posfixArr=post.doTrans();

        ParsePost calc=new ParsePost(posfixArr);

        displayResult.setText(calc.doParse()+"");
    }
    public void clear(View v){
        display.setText("0");
        displayResult.setText("");
    }
    public void delete(View v){
        String s=display.getText().toString();
        if (s.length()>0){
            s=s.substring(0,s.length()-1);
        }
        display.setText(s);
    }
    @Override
    public void onSaveInstanceState(Bundle savedInstanceState){
        super.onSaveInstanceState(savedInstanceState);
        savedInstanceState.putString(EXXPRESSTION,display.getText().toString());
        savedInstanceState.putString(ANSWER,displayResult.getText().toString());
    }
}








