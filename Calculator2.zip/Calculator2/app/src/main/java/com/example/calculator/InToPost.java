package com.example.calculator;

import java.util.ArrayList;
import java.util.List;

public class InToPost {
    private StackX theStack;
    private String input;
    private List<String> outList;

    public InToPost(String input) {
        this.input = input;
        theStack=new StackX(input.length());
        outList=new ArrayList<>();
    }
    public List<String> doTrans(){
        String strB="";

        for (int i=0;i<input.length();i++){
            char ch=input.charAt(i);

            if (Character.isDigit(ch) || (i==0 && input.charAt(0)=='-')){
                strB+=ch;
                while (i+1<input.length() && (Character.isDigit(input.charAt(i+1)) || input.charAt(i+1)=='.')){
                    strB+=input.charAt(++i);
                }
                outList.add(strB);
                strB="";

            }else {
                switch (ch){
                    case '+':
                    case '-':
                        gotOper(ch,1);
                        break;
                    case '*':
                    case '/':
                        gotOper(ch,2);
                        break;
                    case '(':
                        theStack.push('(');
                        break;
                    case ')':
                        gotParent();
                        break;
                    default:
                        break;
                }
            }

        }
        while (!theStack.isEmpty()){
            char c=theStack.pop();
            outList.add(c+"");
        }
        return outList;
    }
    public void gotOper(char opThis,int prec1){
        while (!theStack.isEmpty()){
            char opTop=theStack.pop();
            if (opTop=='('){
                theStack.push(opTop);
                break;
            }else {
                int prec2;
                if (opTop=='+' || opTop=='-'){
                    prec2=1;
                }else {
                    prec2=2;
                }
                if (prec2 < prec1){
                    theStack.push(opTop);
                    break;
                }else {
                    outList.add(opTop+"");
                }
            }
        }
        theStack.push(opThis);
    }
    public void gotParent(){
        while (!theStack.isEmpty()){
            char ch=theStack.pop();
            if (ch=='('){
                break;
            }else {
                outList.add(ch+"");
            }
        }
    }

    public static void main(String[] args) {
        String s="(-25-8)";
        InToPost inToPost=new InToPost(s);

        List<String> list=inToPost.doTrans();
        System.out.println(list);


    }
}