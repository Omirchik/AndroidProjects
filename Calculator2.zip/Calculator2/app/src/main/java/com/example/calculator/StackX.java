package com.example.calculator;

public class StackX {

    private char[] array;
    private int top;
    private int maxSize;

    public StackX(int maxSize) {

        this.maxSize = maxSize;
        array=new char[this.maxSize];
        top=-1;
    }
    public void push(char j){
        array[++top]=j;
    }
    public char pop(){
        return array[top--];
    }
    public char peek(){
        return array[top];
    }
    public boolean isEmpty(){
        return top==-1;
    }
    public boolean isFull(){
        return top==maxSize-1;
    }
    public String doREv(String s){
        for (int i=0;i<s.length();i++){
            this.push(s.charAt(i));
        }
        String output="";
        while (!this.isEmpty()){
            output+=this.pop();
        }
        return output;
    }
}
