package com.example.calculator;

public class Stack {
    private float[] array;
    private int maxSize;
    private int top;
    public Stack(int m){
        maxSize=m;
        array=new float[maxSize];
        top=-1;
    }
    public void push(float value){
        array[++top]=value;
    }
    public float pop(){
        return array[top--];
    }
    public float peek(){
        return array[top];
    }
    public boolean isEmpty(){
        return top==-1;
    }
    public boolean isFull(){
        return top==maxSize-1;
    }
    public void display(){
        int temp=top;
        while (temp>=0){
            System.out.print(array[temp]+" ");
            temp--;
        }
        System.out.println();
    }
}
