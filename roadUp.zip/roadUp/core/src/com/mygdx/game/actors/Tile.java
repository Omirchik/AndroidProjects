package com.mygdx.game.actors;

import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;

public class Tile extends TextButton {

    private int row,col;
    private int id;
    public Tile(String text, Skin skin,String style,int id,int row,int col) {
        super(text, skin, style);
        this.id=id;
        this.row=row;
        this.col=col;
    }
    public int getRow() {
        return row;
    }
    public int getCol() {
        return col;
    }
    public int getId() {
        return id;
    }
}
