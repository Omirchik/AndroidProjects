package com.mygdx.game.Screens;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.g2d.TextureAtlas;
import com.badlogic.gdx.math.Interpolation;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.badlogic.gdx.utils.viewport.StretchViewport;
import com.mygdx.game.Algs.RandomNums;
import com.mygdx.game.Algs.RandomPath;
import com.mygdx.game.Algs.TileStack;
import com.mygdx.game.RoadUp;
import com.mygdx.game.actors.Tile;

import java.util.ArrayList;

import static com.badlogic.gdx.scenes.scene2d.actions.Actions.alpha;
import static com.badlogic.gdx.scenes.scene2d.actions.Actions.delay;
import static com.badlogic.gdx.scenes.scene2d.actions.Actions.fadeIn;
import static com.badlogic.gdx.scenes.scene2d.actions.Actions.moveBy;
import static com.badlogic.gdx.scenes.scene2d.actions.Actions.parallel;
import static com.badlogic.gdx.scenes.scene2d.actions.Actions.sequence;

public class PlayScreen implements Screen {

    private final RoadUp app;

    // Stage and skin
    private Stage stage;
    private Skin skin;
    private String[] colors={"default","tile1","tile2","tile3","tile4"};
    private TileStack stackOfTiles;

    private TileStack yTiles;

    private int boardSize=6;
    // Grid
    private Tile[][] tiles;
    //Target
    private int target;
    public PlayScreen(RoadUp app){
        this.app=app;
        this.stage = new Stage(new StretchViewport(RoadUp.V_WIDTH,RoadUp.V_HEIGHT,app.camera));
    }

    private int indexRandom(int id){

        int range=target/colors.length;
        return id/range;

    }
    @Override
    public void show() {
        target=10;
        Gdx.input.setInputProcessor(stage);
        stage.clear();

        this.skin = new Skin();
        this.skin.addRegions(app.assets.get("ui3/tile.atlas", TextureAtlas.class));
        this.skin.add("default-font",app.font54);
        this.skin.load(Gdx.files.internal("ui3/tile.json"));

        initGrid();

    }
    @Override
    public void render(float delta) {
        Gdx.gl.glClearColor(1f, 1f, 1f, 1f);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
        update(delta);
        stage.draw();
    }
    @Override
    public void resize(int width, int height) {
    }
    @Override
    public void pause() {

    }
    @Override
    public void resume() {

    }
    @Override
    public void hide() {

    }
    private void update(float delta) {
        stage.act(delta);


        if (stackOfTiles.getSum()==target){
            target+=10;
            stage.clear();
            initGrid();
        }

    }
    @Override
    public void dispose() {
        stage.dispose();
    }
    private void initGrid(){
        stackOfTiles=new TileStack(boardSize*boardSize);
        yTiles=new TileStack(boardSize);
        tiles=new Tile[boardSize][boardSize];
        Tile buttonTile;
        float width=stage.getWidth()-100;
        float height=stage.getHeight();
        RandomPath rp=new RandomPath(boardSize);
        System.out.println(rp.toString());
        int[] randomNums=RandomNums.generateEq(target,rp.getCount());
        int next=0;
        int id;
        for (int i = 0; i < boardSize; i++) {
            for (int j = 0; j < boardSize; j++) {
                String style;
                if (rp.getGrid()[i][j]==1){
                    id=randomNums[next++];
                }else {
                    id = (RandomNums.randomNumber(0,target)*2)/3;
                }
                style=colors[indexRandom(id)];
                buttonTile=new Tile(String.valueOf(id),skin,style,id,i,j);
                tiles[i][j]=buttonTile;
                buttonTile.setSize(1f*width/boardSize,height/(boardSize*2f));
    buttonTile.setPosition((stage.getWidth())/2f-(buttonTile.getWidth()+3)*(boardSize/2f)+(buttonTile.getWidth()+3)*j,
            ((height/2+(buttonTile.getHeight()+3)*(boardSize/2f)-buttonTile.getHeight()) - (buttonTile.getHeight()+3)*i));

                buttonTile.addAction(sequence(alpha(0), delay((j + 1 + (i*boardSize))/(5f*boardSize)),
                        parallel(fadeIn(.5f),moveBy(0,-10,.25f, Interpolation.pow5Out))));

                buttonTile.addListener(new ClickListener(){
                    @Override
                    public void clicked(InputEvent event, float x, float y){

                        Tile tile=(Tile)(event.getListenerActor());

                        if (tile.isChecked()) tile.setChecked(false);
                        else tile.setChecked(true);

                        Tile currentTile=stackOfTiles.peek();

                        if (stackOfTiles.isFirst(tile)){
                            tile.setChecked(true);
                        }
                        if (tile.isChecked()){
                            moveBack(tile);
                        }else {
                            move(tile,currentTile);
                        }

                    }
                });
                stage.addActor(tiles[i][j]);
            }
        }
        tiles[boardSize-1][rp.getXpos()].setChecked(true);
        stackOfTiles.push(tiles[boardSize-1][rp.getXpos()]);
        yTiles.push(tiles[boardSize-1][rp.getXpos()]);
    }
    private void move(Tile clickedTile,Tile current){

        int clickedX=clickedTile.getCol();
        int clickedY=clickedTile.getRow();

        int curX=current.getCol();
        int curY=current.getRow();

        if (curY>=clickedY){
            while (curY>clickedY){
                Tile tile=tiles[--curY][curX];
                tile.setChecked(true);
                stackOfTiles.push(tile);
                if (yTiles.peek().getRow()!=clickedY){
                    yTiles.push(stackOfTiles.peek());
                }
            }
            while (yTiles.peek()!=stackOfTiles.peek()){
                stackOfTiles.pop().setChecked(false);
            }
            curX=stackOfTiles.peek().getCol();

            if (curX>clickedX){
                while (curX>clickedX){
                    Tile tile=tiles[curY][--curX];
                    tile.setChecked(true);
                    stackOfTiles.push(tile);
                }
            }else {
                while (curX<clickedX){
                    Tile tile=tiles[curY][++curX];
                    tile.setChecked(true);
                    stackOfTiles.push(tile);
                }
            }
        }
    }
    private void moveBack(Tile clicked){

        while (stackOfTiles.peek()!=null && stackOfTiles.peek()!=clicked){
            stackOfTiles.pop().setChecked(false);
        }
        if (!stackOfTiles.isFirst(clicked)){
            stackOfTiles.pop().setChecked(false);
        }
        while (yTiles.peek().getRow()!=clicked.getRow()){
            yTiles.pop().setChecked(false);
        }
        if (!stackOfTiles.isFirst(yTiles.peek()) && yTiles.peek().getRow()==clicked.getRow() && yTiles.peek().getCol()==clicked.getCol()){
            yTiles.pop().setChecked(false);
        }
    }
}





