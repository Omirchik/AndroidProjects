package com.mygdx.game.Screens;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.math.Interpolation;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Image;
import com.badlogic.gdx.utils.viewport.StretchViewport;
import com.mygdx.game.RoadUp;

import static com.badlogic.gdx.scenes.scene2d.actions.Actions.*;

public class SplashScreen implements Screen {

    private final RoadUp app;
    private Image img;
    private Stage stage;
    public SplashScreen(RoadUp app){
        this.app=app;
        stage=new Stage(new StretchViewport(RoadUp.V_WIDTH,RoadUp.V_HEIGHT,app.camera));

    }

    @Override
    public void show() {

        Runnable transitionRunnable=new Runnable() {
            @Override
            public void run() {
                app.setScreen(app.mainMenuScreen);
            }
        };

        Gdx.input.setInputProcessor(stage);
        Texture splashTexture=app.assets.get("img/splash.png",Texture.class);
        img=new Image(splashTexture);

        img.setOrigin(img.getWidth()/2,img.getHeight()/2);
        img.setPosition(stage.getWidth()/2-img.getWidth()/2,stage.getHeight()/2+img.getImageHeight()/2);

        img.addAction(
                sequence(alpha(0f),scaleTo(.1f,.1f),parallel(fadeIn(1f, Interpolation.pow2),
                scaleTo(2f,2f,1f,Interpolation.pow5),
                moveTo(stage.getWidth()/2-img.getWidth()/2,stage.getHeight()/2-img.getWidth()/2,1f,Interpolation.swing)),
                delay(1f),fadeOut(1f),run(transitionRunnable)));

        stage.addActor(img);

    }

    @Override
    public void render(float delta) {


        Gdx.gl.glClearColor(1f, 1f, 1f, 1);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
        update(delta);
        stage.draw();
    }
    private void update(float delta){
        stage.act(delta);
    }

    @Override
    public void resize(int width, int height) {

    }

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void hide() {

    }

    @Override
    public void dispose() {
        stage.dispose();
    }
}
