package com.mygdx.game.Screens;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.g2d.TextureAtlas;
import com.badlogic.gdx.math.Interpolation;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.badlogic.gdx.utils.viewport.StretchViewport;
import com.mygdx.game.RoadUp;

import static com.badlogic.gdx.scenes.scene2d.actions.Actions.alpha;
import static com.badlogic.gdx.scenes.scene2d.actions.Actions.fadeIn;
import static com.badlogic.gdx.scenes.scene2d.actions.Actions.moveBy;
import static com.badlogic.gdx.scenes.scene2d.actions.Actions.parallel;
import static com.badlogic.gdx.scenes.scene2d.actions.Actions.sequence;

public class MainMenuScreen implements Screen {

    private final RoadUp app;

    private Stage stage;

    private TextButton buttonPlay,buttonExit,buttonRecords;

    private Skin skin;

    public MainMenuScreen(RoadUp app){
        this.app=app;
        stage=new Stage(new StretchViewport(RoadUp.V_WIDTH,RoadUp.V_HEIGHT,app.camera));
    }

    @Override
    public void show() {

        Gdx.input.setInputProcessor(stage);

        stage.clear();

        skin=new Skin();
        skin.addRegions(app.assets.get("ui3/tile.atlas", TextureAtlas.class));
        skin.add("default-font",app.font54);
        skin.load(Gdx.files.internal("ui3/tile.json"));

        initButtons();
    }

    @Override
    public void render(float delta) {

        Gdx.gl.glClearColor(1f, 1f, 1f, 1);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

        update(delta);
        stage.draw();

    }
    private void update(float delta){
        stage.act(delta);
    }
    @Override
    public void resize(int width, int height) {

    }

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void hide() {

    }

    @Override
    public void dispose() {

    }
    private void initButtons(){

        buttonPlay=new TextButton("Play",skin,"default");
        buttonPlay.setSize(stage.getWidth()/2,stage.getHeight()/10);
        buttonPlay.setPosition(stage.getWidth()/2-buttonPlay.getWidth()/2,stage.getHeight()/2+buttonPlay.getHeight()*1.25f);
        buttonPlay.addAction(sequence(alpha(0),
                parallel(fadeIn(.5f),moveBy(0,-100,.5f, Interpolation.pow5Out))));

        buttonPlay.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                app.setScreen(app.playScreen);
            }
        });

        buttonRecords=new TextButton("Records",skin,"default");
        buttonRecords.setSize(stage.getWidth()/2,stage.getHeight()/10);
        buttonRecords.setPosition(stage.getWidth()/2-buttonPlay.getWidth()/2,buttonPlay.getY()-buttonRecords.getHeight()*1.25f);
        buttonRecords.addAction(sequence(alpha(0),
                parallel(fadeIn(.5f),moveBy(0,-100,.5f, Interpolation.pow5Out))));
        buttonRecords.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                app.setScreen(app.playScreen);
            }
        });

        buttonExit = new TextButton("Exit",skin,"default");
        buttonExit.setSize(stage.getWidth()/2,stage.getHeight()/10);
        buttonExit.setPosition(stage.getWidth()/2-buttonExit.getWidth()/2,buttonRecords.getY()-buttonExit.getHeight()*1.25f);
        buttonExit.addAction(sequence(alpha(0),
                parallel(fadeIn(.5f),moveBy(0,-100,.5f, Interpolation.pow5Out))));

        buttonExit.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x,float y) {
                Gdx.app.exit();
            }
        });
        stage.addActor(buttonPlay);
        stage.addActor(buttonRecords);
        stage.addActor(buttonExit);
    }
}
