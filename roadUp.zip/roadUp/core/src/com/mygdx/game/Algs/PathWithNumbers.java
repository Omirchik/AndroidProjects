package com.mygdx.game.Algs;

import java.util.Arrays;

public class PathWithNumbers {

    public static void main(String[] args) {


        RandomPath rp=new RandomPath(5);
        System.out.println(rp.toString());

        int[] arr=RandomNums.generateEq(10,rp.count);
        int c=0;
        System.out.println(Arrays.toString(arr));
        for (int i = 0; i < rp.grid.length; i++) {
            for (int j = 0; j < rp.grid.length; j++) {

                if (rp.grid[i][j]==1){
                    rp.grid[i][j]=arr[c];
                    c++;
                }else {
                    rp.grid[i][j]=RandomNums.randomNumber(0,10);
                }
            }
        }
        System.out.println(rp.toString());

    }

}
