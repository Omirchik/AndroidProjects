package com.mygdx.game.Algs;

public class RandomPath {
    private int n;
    int[][] grid;
    private int min;
    private int max;
    int xpos;
    int count=0;
    public RandomPath(int n) {
        this.n = n;
        this.grid = new int[n][n];
        addRange();
        int ypos=0;
        int xcor;
        xpos=randGen(1,n-1);
        do{
            int forward=randGen(min,max);
            while (forward>0 && ypos<n){
                count++;
                grid[ypos][xpos]=1;
                ypos++;
                forward--;
            }
            if (ypos==n){
                break;
            }
            xcor=randGen(0,max);
            if (xcor>xpos){
                while (xcor>xpos){
                    grid[ypos][xpos]=1;
                    xpos++;
                    count++;
                }
            }else{
                while (xcor<xpos){
                    grid[ypos][xpos]=1;
                    xpos--;
                    count++;
                }
            }
        }while (ypos<=n);
    }
    public int randGen(int min,int max){
        return (int)(Math.random() * ((max - min) + 1)) + min;
    }
    private void addRange(){
        if (n<6){
            min=1;
            max=2;
        }else if (n<9){
            min=2;
            max=4;
        }
        else if (n<12){
            min=3;
            max=5;
        }else{
            min=3;
            max=6;
        }
    }
    public String toString(){
        String s="";
        for (int i = 0; i < n ; i++) {
            for (int j = 0; j < n; j++) {
                s+=grid[i][j]+" ";
            }
            s+="\n";
        }
        return s;
    }
    public static void main(String[] args) {
        RandomPath rp=new RandomPath(5);
        System.out.println(rp.toString());
        System.out.println(rp.xpos);
    }

    public int getXpos() {
        return xpos;
    }

    public int getCount() {
        return count;
    }

    public int[][] getGrid() {
        return grid;
    }
}
