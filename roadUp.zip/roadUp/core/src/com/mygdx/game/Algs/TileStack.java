package com.mygdx.game.Algs;

import com.mygdx.game.actors.Tile;

public class TileStack {
    private Tile[] tiles;
    private int n;
    private int sum=0;
    public TileStack(int size) {
        n=0;
        tiles=new Tile[size];
    }

    public void push(Tile tile){
        sum+=tile.getId();
        tiles[n++]=tile;
    }
    public Tile pop(){
        if (n==1) return null;
        Tile temp=tiles[--n];
        sum+=temp.getId();
        tiles[n]=null;
        return temp;
    }
    public Tile peek(){
        return tiles[n-1];
    }
    public int getN() {
        return n;
    }
    public boolean isFirst(Tile tile){
        return tiles[0].getRow()==tile.getRow() && tiles[0].getCol()==tile.getCol();
    }
    public Tile first(){ return tiles[0]; }
    public boolean isEmpty(){
        return n==0;
    }
    public int getSum() {
        return sum;
    }
    public void printStack(){
        for (int i = 0; i < n; i++){
            System.out.println(tiles[i].getCol() + " " + tiles[i].getRow());
        }
        System.out.println("----------------");
    }
}











