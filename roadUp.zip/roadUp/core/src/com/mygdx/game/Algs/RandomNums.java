package com.mygdx.game.Algs;

import java.util.Arrays;
import java.util.Random;

public class RandomNums {

    public static void main(String[] args) {
        int[] list = generateEq(25,5);

        System.out.println(Arrays.toString(list));
        System.out.println(sum(list));
    }
    public static int[] generateEq(int targetSum, int n) {
        Random r = new Random();
        int[] load = new int[n];
        int sum = 0;
        for (int i = 0; i < n; i++) {
            int next = r.nextInt(targetSum) + 1;
            load[i] = next;
            sum += next;
        }

        double scale = 1d * targetSum / sum;
        sum = 0;
        for (int i = 0; i < n; i++) {
            load[i] = (int) (load[i] * scale);
            sum += load[i];
        }
//take rounding issues into account
        while(sum++ < targetSum) {
            int i = r.nextInt(n);
            load[i]++;
        }
        return load;
    }
    public static int sum(int[] a){
        int count = 0;
        for (int i = 0; i < a.length; i++){
            count += a[i];
        }
        return count;
    }
    public static int randomNumber(int min, int max) {
        Random random = new Random();
        return random.nextInt((max - min) + 1) + min;
    }
}
