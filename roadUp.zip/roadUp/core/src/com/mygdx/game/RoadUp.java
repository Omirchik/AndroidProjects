package com.mygdx.game;

import com.badlogic.gdx.Game;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.assets.AssetManager;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.freetype.FreeTypeFontGenerator;
import com.mygdx.game.Screens.LoadingScreen;
import com.mygdx.game.Screens.MainMenuScreen;
import com.mygdx.game.Screens.PlayScreen;
import com.mygdx.game.Screens.SplashScreen;

public class RoadUp extends Game {

	public static final String TITLE="RoadUp";
	public static int V_WIDTH;
	public static int V_HEIGHT;


	//Fonts
	public BitmapFont font54;


	//Screens
	public LoadingScreen loadingScreen;
	public MainMenuScreen mainMenuScreen;
	public SplashScreen splashScreen;
	public PlayScreen playScreen;

	//Asset manager
	public OrthographicCamera camera;
	public AssetManager assets;


	@Override
	public void create () {

		V_HEIGHT=Gdx.graphics.getHeight();
		V_WIDTH=Gdx.graphics.getWidth();

		System.out.println(V_WIDTH+" "+V_HEIGHT);
		assets=new AssetManager();
		camera=new OrthographicCamera();
		camera.setToOrtho(false,V_WIDTH,V_HEIGHT);

		initFonts();

		loadingScreen=new LoadingScreen(this);
		mainMenuScreen=new MainMenuScreen(this);
		splashScreen=new SplashScreen(this);
		playScreen=new PlayScreen(this);

		this.setScreen(loadingScreen);
	}

	@Override
	public void render () {

		super.render();
	}
	
	@Override
	public void dispose () {
		loadingScreen.dispose();
		mainMenuScreen.dispose();
		playScreen.dispose();
		splashScreen.dispose();
		font54.dispose();
	}
	private void initFonts(){

		FreeTypeFontGenerator generator=new FreeTypeFontGenerator(Gdx.files.internal("fonts/Chunq.ttf"));
		FreeTypeFontGenerator.FreeTypeFontParameter params=new FreeTypeFontGenerator.FreeTypeFontParameter();
		params.size=54;
		params.color= Color.WHITE;
		font54 = generator.generateFont(params);

	}
}
