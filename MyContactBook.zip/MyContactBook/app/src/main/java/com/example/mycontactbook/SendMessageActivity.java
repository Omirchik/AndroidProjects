package com.example.mycontactbook;

import android.Manifest;
import android.content.pm.PackageManager;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class SendMessageActivity extends AppCompatActivity {
    private TextView phone;
    private EditText text;
    private TextView name;
    private Button sendButton;
    private static final int REQUEST_SEND=2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_send_message);

        text=findViewById(R.id.sendMessageText);
        phone=findViewById(R.id.sendMessagePhone);
        sendButton=findViewById(R.id.sendMessagBut);
        name=findViewById(R.id.sendMessageName);

        Bundle bundle=getIntent().getExtras();
        if (bundle!=null){
            phone.setText(bundle.getString("phone"));
            name.setText(bundle.getString("name"));
        }

        sendButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String sendingText=text.getText().toString();
                if (sendingText.length()!=0){
                    sendMessage(sendingText);
                }
            }
        });
    }
    private void sendMessage(String textSending){
        if (!checkPermission(Manifest.permission.SEND_SMS)){
            ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.SEND_SMS},REQUEST_SEND);
        }

        String phoneNumber=phone.getText().toString();
        if (phoneNumber==null || phoneNumber.length()==0){
            return;
        }
        if (checkPermission(Manifest.permission.SEND_SMS)){
            SmsManager smsManager=SmsManager.getDefault();
            smsManager.sendTextMessage(phoneNumber,null,textSending,null,null);
            Toast.makeText(this,"Message Sent!",Toast.LENGTH_SHORT).show();
            text.setText("");
        }else {
            Toast.makeText(this,"Permission denied!",Toast.LENGTH_SHORT).show();
        }
    }
    private boolean checkPermission(String permission){
        int check= ContextCompat.checkSelfPermission(this,permission);
        return check== PackageManager.PERMISSION_GRANTED;
    }

}
