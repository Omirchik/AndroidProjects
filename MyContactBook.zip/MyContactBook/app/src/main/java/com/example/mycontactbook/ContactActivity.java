package com.example.mycontactbook;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class ContactActivity extends AppCompatActivity {
    private ImageView imageView;
    private TextView name;
    private TextView phone;
    private static final int REQUEST_CALL=1;
    private ImageView imageCall;
    private ImageView imageSend;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contact);

        imageView=findViewById(R.id.imageViewDet);
        name=findViewById(R.id.nameText);
        phone=findViewById(R.id.phoneText);

        Bundle bundle=getIntent().getExtras();

        if (bundle!=null){
            imageView.setImageResource(bundle.getInt("url"));
            name.setText(bundle.getString("name"));
            phone.setText(bundle.getString("phone"));
        }

        imageCall=findViewById(R.id.image_call);
        imageSend=findViewById(R.id.image_send);

        imageCall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                makePhoneCall();
            }
        });
        imageSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(ContactActivity.this,SendMessageActivity.class);
                Bundle b=new Bundle();
                b.putString("name",name.getText().toString());
                b.putString("phone",phone.getText().toString());
                i.putExtras(b);
                startActivity(i);
            }
        });
    }
    private void makePhoneCall(){
        String phoneNumber=phone.getText().toString();
        if (phoneNumber.trim().length()>0){
            if (ContextCompat.checkSelfPermission(ContactActivity.this,
                    Manifest.permission.CALL_PHONE)!= PackageManager.PERMISSION_GRANTED){
                ActivityCompat.requestPermissions(ContactActivity.this,new String[]{Manifest.permission.CALL_PHONE},REQUEST_CALL);
            }else {
                String dial="tel:"+phoneNumber;
                Intent i=new Intent(Intent.ACTION_CALL,Uri.parse(dial));
                startActivity(i);

            }
        }
    }

    public static Intent newIntent(Context content, ArrayList<Contact> contacts, int position){
        Intent intent=new Intent(content,ContactActivity.class);
        intent.putExtra("url",contacts.get(position).getImage());
        intent.putExtra("name",contacts.get(position).getName());
        intent.putExtra("phone",contacts.get(position).getPhoneNumber());
        return intent;
    }
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (requestCode == REQUEST_CALL) {
            if (grantResults.length>0 && grantResults[0]==PackageManager.PERMISSION_GRANTED){
                makePhoneCall();
            }else {
                Toast.makeText(this,"PERMISSION DENIED",Toast.LENGTH_SHORT).show();
            }
        }

    }
}




