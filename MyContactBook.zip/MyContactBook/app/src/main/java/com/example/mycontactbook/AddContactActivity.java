package com.example.mycontactbook;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import java.io.BufferedWriter;
import java.io.File;

import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Formatter;


public class AddContactActivity extends AppCompatActivity {
    Button addBut;
    Button viewBut;
    EditText textName;
    EditText number;
    DataBaseHelper db;
    private static final String TAG="AddContactActivity";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_contact);

        addBut=findViewById(R.id.add_but);
        textName=findViewById(R.id.edit_name);
        number=findViewById(R.id.edit_number);
        viewBut=findViewById(R.id.show_but);
        db=new DataBaseHelper(this);

        addBut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String nameS=textName.getText().toString();
                String phoneNumber=number.getText().toString();
                boolean b=true;
                int i=0;
                if (phoneNumber.charAt(0)=='+'){
                    i++;
                }
                for (;i<phoneNumber.length();i++){
                    if (!Character.isDigit(phoneNumber.charAt(i))){
                        b=false;
                        break;
                    }
                }

                if (nameS.length()==0){
                    Toast.makeText(AddContactActivity.this,"Empty Name",Toast.LENGTH_SHORT).show();
                }else if (!b){
                    Toast.makeText(AddContactActivity.this,"Incorrect phone number",Toast.LENGTH_SHORT).show();
                }else {
                    addData(nameS+" "+phoneNumber);
                }
            }
        });
        viewBut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(AddContactActivity.this,MainActivity.class);
                startActivity(i);
            }
        });
    }
    public void addData(String newData){
        boolean b=db.addData(newData);
        if (b){
            Toast.makeText(AddContactActivity.this,"Added",Toast.LENGTH_SHORT).show();
        }else {
            Toast.makeText(AddContactActivity.this,"not Added",Toast.LENGTH_SHORT).show();
        }
    }
}



