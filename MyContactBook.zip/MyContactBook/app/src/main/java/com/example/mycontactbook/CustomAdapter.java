package com.example.mycontactbook;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class CustomAdapter extends ArrayAdapter<Contact>{
    ArrayList<Contact> contacts;
    public CustomAdapter(@NonNull Context context, ArrayList<Contact> c) {
        super(context, R.layout.list_item);
        contacts=c;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {

        LayoutInflater inflater = LayoutInflater.from(getContext());
        View custom_view = inflater.inflate(R.layout.list_item,parent,false);

        ImageView iv=custom_view.findViewById(R.id.imageView);
        TextView name_tv=custom_view.findViewById(R.id.TextViewName);
        TextView phone=custom_view.findViewById(R.id.TextViewDesc);
        iv.setImageResource(contacts.get(position).getImage());
        name_tv.setText(contacts.get(position).getName());
        phone.setText(contacts.get(position).getPhoneNumber());
        return custom_view;
    }

    @Override
    public int getCount() {
        return contacts.size();
    }
}















